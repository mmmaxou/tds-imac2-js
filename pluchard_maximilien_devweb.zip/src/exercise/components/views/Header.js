import { h } from 'hyperapp'
export default () =>
  <header className='navbar navbar-default'>
    <div className="container-fluid">
      <div className="navbar-header">
        <h1>La seule formation publique d'ingénieurs alliant arts et sciences</h1>
      </div>
    </div>
  </header>
